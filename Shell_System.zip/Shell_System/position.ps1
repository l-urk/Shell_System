# content of position.ps1

Add-Type @"
    using System;
    using System.Runtime.InteropServices;

    public class User32 {
        [DllImport("user32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter, int X, int Y, int cx, int cy, uint uFlags);
    }
"@

# Set the X and Y coordinates for the window position
$X = 100
$Y = 50

# Get the current console window handle
$hWnd = [System.Diagnostics.Process]::GetCurrentProcess().MainWindowHandle

# Set the window position
[User32]::SetWindowPos($hWnd, [IntPtr]::Zero, $X, $Y, 800, 600, 0x0001 -bor 0x0004 -bor 0x0040)
